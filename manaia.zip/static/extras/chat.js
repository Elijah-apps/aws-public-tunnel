
const chatbotToggler = document.querySelector(".chatbot-toggler");
const closeBtn = document.querySelector(".close-btn");
const chatInput = document.querySelector(".chat-input textarea");
const sendChatbtn = document.querySelector(".chat-input span");
const chatbox = document.querySelector(".chatbox");

let userMessage = null; // Variable to store user's message
const inputInitHeight = chatInput.scrollHeight;

// Object to store predefined responses for specific keywords
const predefinedResponses = {
  "hello": ["Hi there!😊", "Hello! How can I help you?😊", "Hey! What's up?😊"],
  "are you a human": ["I am an AI and was developed by manaia ai😊", "I am a bot developed by Manaia AI😊", "I am not living like you but i am developed by Manaia AI😊"],
  "are you human": ["I am an AI and was developed by Manaia AI", "I am a bot developed by Manaia AI", "I am not living like you but i am developed by Manaia AI"],
 
  "name": ["I'm your friendly chatbot!", "You can call me Chatbot!", "I'm Chatbot, nice to meet you!"],
   "location": [
        "Our head office is in Christchurch, New Zealand. 🌏",
        "Manaia AI is located in Christchurch, New Zealand. 🌍",
        "We are based in Christchurch, New Zealand. 🌎"
    ],
    "how are you": [
        "I'm doing great! How can I help you today? 😊",
        "I'm just a bot, but I'm here to help you! 🤖",
        "I'm doing well, thanks for asking! How can I assist you? 🤗"
    ],
    "bye": [
        "Goodbye! Have a great day! 👋",
        "See you later! Take care! 😊",
        "Bye! Feel free to chat with me anytime! 👋"
    ],
    "features": [
        "These AI Assistant Avatars are trainable, meaning they’ll teach and work according to the style and language of the business. That’s far more valuable than just using a standard AI chatbot. 🤖",
        "Our AI Assistant Avatars can be trained to match your business's style and language, offering more value than a standard AI chatbot. 💼",
        "Our avatars are customizable and can be trained to work according to your business's unique style and language. 🌟"
    ],
     "can you tell me about manaia ai": [
        "Manaia AI lets you clone yourself or any expert into an AI real-time and lifelike expert advisor by providing a clone of yourself or a business expert who talks and mentors your buyers into sales or contacts. You can get to know more about us from the about section of the website. Is there anything else I can help you with? 🤔",
        "With Manaia AI, you can create a lifelike AI advisor that clones yourself or any expert. Visit the about section on our website for more details. Anything else I can assist you with? 😊",
        "Manaia AI allows you to create an AI clone of yourself or an expert to mentor your buyers. Check out the about section on our website for more info. Need help with anything else? 🤗"
    ],
    "can you tell me more about manaia ai": [
        "Manaia AI lets you clone yourself or any expert into an AI real-time and lifelike expert advisor by providing a clone of yourself or a business expert who talks and mentors your buyers into sales or contacts. You can get to know more about us from the about section of the website. Is there anything else I can help you with? 🤔",
        "With Manaia AI, you can create a lifelike AI advisor that clones yourself or any expert. Visit the about section on our website for more details. Anything else I can assist you with? 😊",
        "Manaia AI allows you to create an AI clone of yourself or an expert to mentor your buyers. Check out the about section on our website for more info. Need help with anything else? 🤗"
    ],
    "projects": [
        "Manaia AI has launched many projects. You can view them on our website: https://www.manaia.ai/project.html. This link will take you there directly. Is there anything else you would like to know? 🌐",
        "We have several projects you can explore on our website: https://www.manaia.ai/project.html. Is there anything else you need? 🌍",
        "You can see our projects at https://www.manaia.ai/project.html. Let me know if there's anything else you want to know! 🌟"
    ],
    "installation": [
        "Manaia AI has a well-detailed explanation on the steps to be taken in the userflow section of the website. Manaia AI will provide any assistance needed for you to install the chatbot on your website. Is there anything else I can help you with? 🛠️",
        "You can find detailed installation steps in the userflow section of our website. We're here to help with any assistance you need. Anything else I can assist you with? 🤔",
        "Check the userflow section on our website for installation steps. We're available to help you with the process. Need help with anything else? 😊"
    ],
     "how can i install the chatbot on my website": [
        "Manaia AI has a well-detailed explanation on the steps to be taken in the userflow section of the website. Manaia AI will provide any assistance needed for you to install the chatbot on your website. Is there anything else I can help you with? 🛠️",
        "You can find detailed installation steps in the userflow section of our website. We're here to help with any assistance you need. Anything else I can assist you with? 🤔",
        "Check the userflow section on our website for installation steps. We're available to help you with the process. Need help with anything else? 😊"
    ],
     "how can i install it": [
        "Manaia AI has a well-detailed explanation on the steps to be taken in the userflow section of the website. Manaia AI will provide any assistance needed for you to install the chatbot on your website. Is there anything else I can help you with? 🛠️",
        "You can find detailed installation steps in the userflow section of our website. We're here to help with any assistance you need. Anything else I can assist you with? 🤔",
        "Check the userflow section on our website for installation steps. We're available to help you with the process. Need help with anything else? 😊"
    ],
    "pricing": [
        "Manaia AI provides comprehensive chatbot features and allows you to select the features you want to pay for. You can go to the Pricing menu for more information. Is there anything else I can help you with? 💰",
        "Our pricing is flexible, allowing you to choose the features you need. Visit the Pricing menu for details. Anything else I can assist you with? 🤔",
        "We offer a range of features you can select from. Check the Pricing menu on our website for more info. Need help with anything else? 💼"
    ],
    "features": [
        "These AI Assistant Avatars are trainable on your data, meaning they’ll teach and work according to the style and language of the business. That’s far more valuable than just using a standard AI chatbot. Is there anything else I can help you with? 🤖",
        "Our avatars can be trained on your data to match your business's style and language, offering more value than a standard AI chatbot. Anything else I can assist you with? 💼",
        "Our AI Assistant Avatars are customizable and trainable to fit your business's unique style and language. Need help with anything else? 🌟"
    ],
    "contact": [
        "You can contact us by filling the contact form on our website: https://www.manaia.ai/contact Is there anything else I can help you with? 📞",
        "Reach out to us via the contact form on our website: https://www.manaia.ai/contact Anything else I can assist you with? 🤔",
        "You can get in touch with us through our contact form at https://www.manaia.ai/contact Need help with anything else? 😊"
    ],
    "comparison": [
        "Manaia AI is far more than another GPT bot or automation tool offer. The next revolution in AI is customization, which is what every business really wants. This tool lets you customize data training & knowledge, personality, coaching style, avatar character, & more. This is the only app where you can have an AI replica of you talking to clients in your style, philosophy, and avatar - NOT a cold lifeless bot. Is there anything else I can help you with? 🤖",
        "Our AI offers customization in data training, personality, coaching style, and more, making it unique compared to other GPT bots. Anything else I can assist you with? 🌟",
        "Manaia AI allows for extensive customization, creating an AI replica of you that interacts with clients in your style. Need help with anything else? 😊"
    ],
    "devices": [
        "Yes. Manaia AI is 100% cloud-based, so it works on any system, device, or screen size, including mobile, from anywhere in the world. Is there anything else I can help you with? 📱",
        "Absolutely! Manaia AI is cloud-based and works on any device or screen size, including mobile. Anything else I can assist you with? 🌐",
        "Yes, Manaia AI is fully cloud-based and compatible with all devices and screen sizes. Need help with anything else? 😊"
    ],
    "updates": [
        "Yes. We’re constantly updating the technology to keep it working smoothly and as powerfully as possible. Is there anything else I can help you with? 🔄",
        "Yes, we regularly update the app to ensure it runs smoothly and efficiently. Anything else I can assist you with? 🌟",
        "Absolutely! We continuously update the app to maintain its performance. Need help with anything else? 😊"
    ],
    "guarantee": [
        "Yes! If you have paid for something you have not used and are not fully satisfied, we offer a full refund. Is there anything else I can help you with? 💸",
        "Yes, we offer a money-back guarantee if you're not fully satisfied with your purchase. Anything else I can assist you with? 😊",
        "Absolutely! We provide a full refund if you're not satisfied with your purchase. Need help with anything else? 💰"
    ],
  
   
    "payment options": [
        "Yes, we have options for monthly or annual auto payments. If you pay annually, you only pay for 11 months. Sometimes there is a small one-off setup fee if you have a complex site. Is there anything else I can help you with? 💳",
        "Absolutely! We offer both monthly and annual payment options. By choosing the annual plan, you only pay for 11 months. There might be a small setup fee for complex sites. Anything else I can assist you with? 😊",
        "Yes, you can choose between monthly and annual payments. Paying annually means you only pay for 11 months. Occasionally, there's a small setup fee for complex sites. Need help with anything else? 🤔",
        "We provide both monthly and annual payment plans. If you opt for the annual plan, you get a discount and pay for just 11 months. A small setup fee may apply for complex sites. Anything else I can help with? 🌟",
        "Yes, we offer monthly and annual payment options. Annual payments come with a discount, so you only pay for 11 months. Sometimes, there's a small setup fee for complex sites. Is there anything else you need? 💼"
    ],
    "location and jobs": [
        "Our head office is in Christchurch, New Zealand. We also have managers in Australia, London, Canada, USA, and Europe. Yes, we are always looking for smart salespeople/managers and partnerships in all regions. Is there anything else I can help you with? 🌏",
        "We are based in Christchurch, New Zealand, with managers in Australia, London, Canada, USA, and Europe. We are always on the lookout for talented salespeople/managers and partnerships. Anything else I can assist you with? 😊",
        "Our head office is located in Christchurch, New Zealand. We have managers in various regions including Australia, London, Canada, USA, and Europe. We are always seeking smart salespeople/managers and partnerships. Need help with anything else? 🤔",
        "Christchurch, New Zealand is where our head office is. We also have managers in Australia, London, Canada, USA, and Europe. We are always looking for smart salespeople/managers and partnerships. Anything else I can help with? 🌟",
        "Our main office is in Christchurch, New Zealand, but we have managers in Australia, London, Canada, USA, and Europe. We are always looking for talented salespeople/managers and partnerships. Is there anything else you need? 💼"
    ],
    "designer": [
        "Manaia AI is designed by Clemmy Technological Network. You can reach them at fagbuyiclement14@gmail.com. 📧",
        "The design of Manaia AI is by Clemmy Technological Network. Contact them at fagbuyiclement14@gmail.com. 😊",
        "Clemmy Technological Network designed Manaia AI. You can email them at fagbuyiclement14@gmail.com. 💻",
        "Manaia AI was designed by Clemmy Technological Network. Reach out to them at fagbuyiclement14@gmail.com. 📧",
        "Designed by Clemmy Technological Network, you can contact them at fagbuyiclement14@gmail.com. 💼"
    ],
    "cost": [
        "The pricing system on Manaia AI can be found on their website. You will pay based on the features of the chatbot you want. Is there anything else I can help you with? 💰",
        "You can find the pricing details on the Manaia AI website. The cost depends on the features you choose. Anything else I can assist you with? 😊",
        "Pricing information is available on the Manaia AI website. Costs vary based on the features you select. Need help with anything else? 🤔",
        "Check the Manaia AI website for pricing details. The cost depends on the chatbot features you want. Anything else I can help with? 🌟",
        "The pricing details are on the Manaia AI website. You pay based on the features you choose. Is there anything else you need? 💼"
    ],
    "cost": [
        "The pricing system on Manaia AI can be found on their website. You will pay based on the features of the chatbot you want. Is there anything else I can help you with? 💰",
        "You can find the pricing details on the Manaia AI website. The cost depends on the features you choose. Anything else I can assist you with? 😊",
        "Pricing information is available on the Manaia AI website. Costs vary based on the features you select. Need help with anything else? 🤔",
        "Check the Manaia AI website for pricing details. The cost depends on the chatbot features you want. Anything else I can help with? 🌟",
        "The pricing details are on the Manaia AI website. You pay based on the features you choose. Is there anything else you need? 💼"
    ],
    "affirmative": [
        "Okay. How can I be of help? 😊",
        "Great! How can I assist you? 🤗",
        "Good to hear! What do you need help with? 🤔",
        "Awesome! How can I help you today? 🌟",
        "Glad to hear that! What can I do for you? 💼"
    ],
    "affirmative": [
        "What would you like to know about Manaia AI? Please be clear with your questions. 😊",
        "Sure! What do you want to know about Manaia AI? 🤔",
        "Yes, of course! What information are you looking for about Manaia AI? 🌟",
        "Absolutely! What would you like to ask about Manaia AI? 💼",
        "Yes! Please let me know what you want to know about Manaia AI. 😊"
    ],
    "negative": [
        "Okay. It was nice chatting with you. If I was not able to answer any of your questions, please use the contact form for proper information. Provide them with the name you inputted before and they will get back to you as soon as possible. Enjoy your day! 😊",
        "Alright. It was great talking to you. If you need more information, please use the contact form and mention your name. They will respond as soon as possible. Have a wonderful day! 🌟",
        "No problem. If you have further questions, please use the contact form and provide your name. They will get back to you soon. Have a great day! 💼",
        "Okay. If you need more assistance, please use the contact form and mention your name. They will respond promptly. Enjoy your day! 😊",
        "Got it. If you need more help, please use the contact form and include your name. They will get back to you quickly. Have a nice day! 🌟"
    ],
    "pricing": [
        "Manaia AI provides comprehensive chatbot features and allows you to select the features you want to pay for. You can go to the Pricing menu for more information. Is there anything else I can help you with? 💰",
        "You can find detailed pricing information on the Manaia AI website. The cost depends on the features you choose. Anything else I can assist you with? 😊",
        "Pricing details are available on the Manaia AI website. Costs vary based on the features you select. Need help with anything else? 🤔",
        "Check the Pricing menu on the Manaia AI website for detailed information. The cost depends on the features you want. Anything else I can help with? 🌟",
        "The Pricing menu on the Manaia AI website has all the details. You pay based on the features you choose. Is there anything else you need? 💼"
    ],
    "phone number": [
        "You can reach Manaia AI at +64 3 900 1508. 📞",
        "The phone number for Manaia AI is +64 3 900 1508. 😊",
        "Contact Manaia AI at +64 3 900 1508. 📱",
        "You can call Manaia AI at +64 3 900 1508. ☎️",
        "Reach out to Manaia AI at +64 3 900 1508. 📞"
    ],
    "office location": [
        "Manaia AI is located at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand. 🌏",
        "The office of Manaia AI is at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand. 🌍",
        "You can find Manaia AI at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand. 🌎",
        "Manaia AI's office is located at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand. 📍",
        "Visit Manaia AI at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand. 🌟"
    ],
  
    "how can i contact manaia ai": [
        "You can visit us at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand, call +64 3 900 1508, or email us at alan@insight-ai-systems.com. 📞",
        "Reach out to us at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand, or call +64 3 900 1508. You can also email us at alan@insight-ai-systems.com. 😊",
        "You can contact us by visiting Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand, calling +64 3 900 1508, or emailing alan@insight-ai-systems.com. 📧",
        "Feel free to visit us at Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand, call us at +64 3 900 1508, or email alan@insight-ai-systems.com. 🌟",
        "You can get in touch with us by visiting Unit 2/1 Doric Way, Islington, Christchurch, 8042 New Zealand, calling +64 3 900 1508, or emailing alan@insight-ai-systems.com. 💼"
    ],
    "email": [
        "The official email of Manaia AI is alan@insight-ai-systems.com. 📧",
        "You can reach Manaia AI at alan@insight-ai-systems.com. 😊",
        "Contact Manaia AI via email at alan@insight-ai-systems.com. 📩",
        "Our email address is alan@insight-ai-systems.com. Feel free to reach out! 🌟",
        "You can email us at alan@insight-ai-systems.com. 💼"
    ]
};

// Function to check if the user's message matches any predefined keywords
// const matchKeyword = (message) => {
  const keywords = {
      "how can i contact manaia ai": ["how can i get in touch with manaia ai", "how can i contact manaia ai"],
    "hello": ["hi there", "hi", "hey"],
    "are you human": ["are you human", "are you living", "are you alive"],
    "are you a human": ["are you a human", "are you human", "re you a human"],
    "how are you": ["how are you", "how's it going", "how are you doing"],
    "name": ["what's your name", "what is your name", "can i know your name"],
    "location": ["where is manaia ai located", "location of manaia ai", "where are you located"],
    
      "features": ["tell me about your features", "what are the features of manaia ai", "features of manaia ai"],
      "more about manaia ai": ["i want to know more about manaia ai", "tell me more about manaia ai", "details about manaia ai", "can you tell me more about manaia ai", "can you tell me about manaia ai"],
      "projects": ["i want to know projects of manaia ai", "manaia ai projects", "what projects has manaia ai done"],
      "installation": ["how can i install manaia ai on my website", "setup manaia ai on my site", "How can i install the chatbot on my website"],
      "pricing": ["what is the pricing of manaia ai", "how much does manaia ai cost", "manaia ai pricing"],
      "contact": ["contact manaia ai", "reach out to manaia ai"],
      "comparison": ["i already have an ai chatbot app, how is this better", "why is manaia ai better", "compare manaia ai with other chatbots"],
      "devices": ["does manaia ai work on all devices", "is manaia ai compatible with all devices", "manaia ai device compatibility"],
      "updates": ["will the app be updated regularly", "manaia ai updates", "how often is manaia ai updated"],
      "guarantee": ["is there a money-back guarantee for manaia ai", "manaia ai refund policy", "can i get a refund for manaia ai", "what is the refund policy of manaia ai"],
      "payment options": ["is this a monthly fee, can i pay annually and get a discount", "manaia ai payment options", "can i pay annually for manaia ai"],
      "location and jobs": ["where are you based and do you have any jobs going on", "manaia ai location and jobs", "manaia ai office and job openings"],
      "designer": ["who designed manaia ai", "manaia ai designer", "who created manaia ai"],
      "cost": ["how much will it cost", "what is the price", "manaia ai cost", "What is the cost of manaia ai", "What is the cost of setting up manaia ai"],
      "affirmative": ["good", "yes", "sure"],
      "negative": ["no", "not interested"],
      "phone number": ["what is the phone number of manaia ai office", "manaia ai contact number", "manaia ai phone number"],
      "office location": ["what is the location of manaia ai office", "manaia ai office address", "where is manaia ai located"],
      "email": ["what is the email of manaia ai", "manaia ai email address", "how to email manaia ai"]
  
  
  };

const matchKeyword = (message) => {
    for (const key in keywords) {
        for (const phrase of keywords[key]) {
            if (message.includes(phrase)) {
                return key;
            }
        }
    }
    return null;
};

const createChatLi = (message, className) => {
  // Create a chat <li> element with passed message and class name
  const chatLi = document.createElement("li");
  chatLi.classList.add("chat", className);
  let chatContent =
    className === "outgoing"
      ? `<p></p>`
      : `<img src="./logo1.png" alt="" width='50 px' height='50 px'><p></p>`;
  chatLi.innerHTML = chatContent;
  chatLi.querySelector("p").textContent = message;
  return chatLi; // return chat <li> element
};

const generateResponse = async (incomingChatli) => {
  // Generate a response based on the user's message
  const messageElement = incomingChatli.querySelector("p");
  const userMessageLower = userMessage.toLowerCase();
  let response = "I'm not sure how to respond to that.";

  const matchedKey = matchKeyword(userMessageLower);
  if (matchedKey && predefinedResponses[matchedKey]) {
    const responses = predefinedResponses[matchedKey];
    const randomIndex = Math.floor(Math.random() * responses.length);
    response = responses[randomIndex];
  } else {
    // Use OpenAI API for unmatched messages
    const API_KEY = "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"; // Replace with your actual API key
    const API_URL = "https://api.openai.com/v1/chat/completions";

    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "user",
            content: userMessage,
          },
        ],
      }),
    };

    try {
      const res = await fetch(API_URL, requestOptions);
      const data = await res.json();
      response = data.choices[0].message.content.trim();
    } catch (error) {
      response = "Oops! Something went wrong. Please try again.";
    }
  }

  // Set the response as paragraph text
  messageElement.textContent = response;
  chatbox.scrollTo(0, chatbox.scrollHeight);
};

const handleChat = () => {
  userMessage = chatInput.value.trim(); // Get user entered message and remove extra whitespace
  if (!userMessage) return;

  // Clear the input textarea and set its height to default
  chatInput.value = "";
  chatInput.style.height = `${inputInitHeight}px`;

  // Append the user's message to the chatbox
  const outgoingChatli = createChatLi(userMessage, "outgoing");
  chatbox.appendChild(outgoingChatli);
  chatbox.scrollTo(0, chatbox.scrollHeight);

  setTimeout(() => {
    // Display "Typing..." message while waiting for the response
    const incomingChatli = createChatLi("Typing...", "incoming");
    chatbox.appendChild(incomingChatli);
    generateResponse(incomingChatli);
  }, 600);
};

chatInput.addEventListener("input", () => {
  // Adjust the height of the input textarea based on its content
  chatInput.style.height = `${inputInitHeight}px`;
  chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
  // If Enter key is pressed without the Shift key and the window
  // width is greater than 800px, handle the chat
  if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
    e.preventDefault();
    handleChat();
  }
});

sendChatbtn.addEventListener("click", handleChat);
closeBtn.addEventListener("click", () =>
  document.body.classList.remove("show-chatbot")
);
chatbotToggler.addEventListener("click", () =>
  document.body.classList.toggle("show-chatbot")
);
