document.getElementById('feedbackForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const feedback = document.getElementById('feedback').value;
    if (feedback) {
        alert('Feedback sent: ' + feedback);
        document.getElementById('feedback').value = '';
    } else {
        alert('Please enter your feedback before sending.');
    }
});
