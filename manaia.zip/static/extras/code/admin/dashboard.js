fetch('fetch_click_data.php')
    .then(response => response.json())
    .then(data => {
        const labels = data.map(entry => entry.click_date);
        const counts = data.map(entry => entry.click_count);

        const ctx = document.getElementById('clickChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Number of Clicks',
                    data: counts,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1,
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));
