const natural = require('natural');
const stemmer = natural.PorterStemmer;

const word = 'running';
const stemmedWord = stemmer.stem(word);

console.log(`Stemmed form of "${word}": ${stemmedWord}`);
