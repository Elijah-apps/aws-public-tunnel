
(function() {
  let chatbotVisible = false;
  let minimized = false;
  let styleSheet;

  function getCustomColors() {
      const colorDefinitions = document.getElementById('chatbot-colors');
      if (colorDefinitions) {
          try {
              return JSON.parse(colorDefinitions.textContent);
          } catch (e) {
              console.error('Error parsing custom colors:', e);
          }
      }
      return {};
  }







      // Function to get the bot_id from the script URL by script tag ID
      function getBotId() {
        // Get the script element by ID
        const script = document.getElementById('chatbot-script');

        // Check if the script element exists
        if (script) {
            const src = script.src; // Get the src attribute
            const params = new URLSearchParams(src.split('?')[1]); // Split on '?' and parse the query string

            // Check if the bot_id parameter exists
            if (params.has('bot_id')) {
                return params.get('bot_id'); // Return the value of bot_id
            }
        }

        return null; // Return null if not found
    }

    // Use the getBotId function
    const BOTID = getBotId();

  const defaultColors = {
      primary: '#007bff',
      secondary: '#6c757d',
      background: '#ffffff',
      text: '#333333',
      headerBackground: '#007bff',
      headerText: '#ffffff',
      userMessageBackground: '#007bff',
      userMessageText: '#ffffff',
      botMessageBackground: '#f0f0f0',
      botMessageText: '#333333',
      inputBorder: '#cccccc',
      sendButtonBackground: '#007bff',
      sendButtonText: '#ffffff',
      footerBackground: '#f8f9fa',
      footerText: '#6c757d',
      toggleButtonBackground: '#007bff',
      toggleButtonIcon: '#ffffff'
  };

  function updateStyles() {
      const customColors = getCustomColors();
      const colors = {...defaultColors, ...customColors};

      const styles = `
          #chatbot{position:fixed;bottom:20px;right:20px;width:300px;height:400px;background-color:${colors.background};border:1px solid ${colors.secondary};box-shadow:0 0 10px rgba(0,0,0,.1);display:flex;flex-direction:column;border-radius:8px;z-index:1000;font-family:Arial,sans-serif}
          #chatbot *{box-sizing:border-box}
          #chatbot.minimized{height:50px;overflow:hidden}
          #chatbot.minimized .chat-messages,#chatbot.minimized .input-area,#chatbot.minimized .chat-footer{display:none}
          .chat-header{background-color:${colors.headerBackground};color:${colors.headerText};padding:10px;border-top-left-radius:8px;border-top-right-radius:8px;display:flex;justify-content:space-between;align-items:center;cursor:pointer}
          .chat-header img{width:30px;height:30px;border-radius:50%;margin-right:10px}
          .online-status{width:10px;height:10px;background-color:#28a745;border-radius:50%;margin-right:5px}
          .chat-welcome{background-color:${colors.primary}22;color:${colors.primary};font-size:.875rem;padding:10px;border-radius:4px;margin:10px;text-align:center;white-space:nowrap}
          .chat-messages{flex:1;padding:10px;overflow-y:auto;display:flex;flex-direction:column;gap:10px}
          .chat-message{max-width:80%;padding:8px 12px;border-radius:12px;margin-bottom:5px;word-wrap:break-word}
          .user-message{align-self:flex-end;background-color:${colors.userMessageBackground};color:${colors.userMessageText}}
          .bot-message{align-self:flex-start;background-color:${colors.botMessageBackground};color:${colors.botMessageText}}
          .input-area{display:flex;padding:10px;border-top:1px solid ${colors.inputBorder}}
          .message-input{flex:1;padding:10px;border:1px solid ${colors.inputBorder};border-radius:4px}
          .send-button{padding:10px;background-color:${colors.sendButtonBackground};color:${colors.sendButtonText};border:none;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;margin-left:5px}
          .send-button i{font-size:1.1rem}
          .chat-footer{background-color:${colors.footerBackground};padding:5px;text-align:center;font-size:.75rem;color:${colors.footerText}}
          #chat-toggle{position:fixed;bottom:20px;right:20px;background-color:${colors.toggleButtonBackground};color:${colors.toggleButtonIcon};border:none;border-radius:50%;width:60px;height:60px;font-size:24px;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,.2);z-index:999}
          .typing-indicator{display:flex;align-items:center;align-self:flex-start;background-color:${colors.botMessageBackground};color:${colors.botMessageText};padding:8px 12px;border-radius:12px;margin-bottom:5px}
          .typing-indicator span{height:8px;width:8px;background-color:${colors.botMessageText};border-radius:50%;display:inline-block;margin-right:5px;animation:typing 1s infinite}
          .typing-indicator span:nth-child(2){animation-delay:.2s}
          .typing-indicator span:nth-child(3){animation-delay:.4s}
          @keyframes typing{0%{opacity:.4;transform:scale(1)}50%{opacity:1;transform:scale(1.2)}100%{opacity:.4;transform:scale(1)}}
      `;

      if (styleSheet) {
          styleSheet.innerText = styles;
      } else {
          styleSheet = document.createElement("style");
          styleSheet.type = "text/css";
          styleSheet.innerText = styles;
          document.head.appendChild(styleSheet);
      }
  }

  function loadFontAwesome() {
      if (!document.querySelector('link[href*="font-awesome"]')) {
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css';
          document.head.appendChild(link);
      }
  }

  function createChatbot() {
      const chatbot = document.createElement('div');
      chatbot.id = 'chatbot';
      chatbot.style.display = 'none';
      chatbot.innerHTML = `
          <div class="chat-header">
              <div style="display:flex;justify-content: flex-start; ">
                 <img src="https://avatar.iran.liara.run/public/9'" alt="Chatbot" />
                  <br>
                  <span style='font-size:9px'>Online</span>
              </div>
                <span>Manaia AI</span>
              <div>
                  <button id="minimizeChat" style="background:none;color:white;border:none;cursor:pointer;margin-right:5px;">_</button>
                  <button id="closeChat" style="background:none;color:white;border:none;cursor:pointer;">✖</button>
              </div>
          </div>
          <div class="chat-welcome">Welcome! How can I assist you today?</div>
          <div class="chat-messages"></div>
          <div class="input-area">
              <input type="text" class="message-input" placeholder="Type your message..." />
              <button class="send-button"><i class="fas fa-arrow-up"></i></button>
          </div>
          <div class="chat-footer">Powered by Manaia AI</div>
      `;
      document.body.appendChild(chatbot);

      const toggleButton = document.createElement('button');
      toggleButton.id = 'chat-toggle';
      toggleButton.innerHTML = '<i class="fas fa-comment-alt"></i>';
      toggleButton.onclick = toggleChat;
      document.body.appendChild(toggleButton);

      document.getElementById('closeChat').addEventListener('click', toggleChat);
      document.getElementById('minimizeChat').addEventListener('click', minimizeChat);
      document.querySelector('.send-button').addEventListener('click', sendMessage);
      document.querySelector('.message-input').addEventListener('keypress', function(e) {
          if (e.key === 'Enter') sendMessage();
      });

      document.querySelector('.chat-header').addEventListener('dblclick', minimizeChat);
  }

  function toggleChat() {
      const chatbot = document.getElementById('chatbot');
      const toggleButton = document.getElementById('chat-toggle');
      chatbotVisible = !chatbotVisible;
      chatbot.style.display = chatbotVisible ? 'flex' : 'none';
      toggleButton.style.display = chatbotVisible ? 'none' : 'flex';
  }

  function minimizeChat() {
      const chatbot = document.getElementById('chatbot');
      minimized = !minimized;
      chatbot.classList.toggle('minimized');
  }

  function sendMessage() {
      const messageInput = document.querySelector('.message-input');
      const message = messageInput.value.trim();
      if (message) {
          displayMessage('You', message, 'user-message');
          messageInput.value = '';
          showTypingIndicator();
          
          fetch('http://127.0.0.1:5000/run/embed/server', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({ msg: message,assistant_id: BOTID}),
          })
          .then(response => response.json())
          .then(data => {
              hideTypingIndicator();
              handleResponse(data);
          })
          .catch(error => {
              hideTypingIndicator();
              console.error('Error:', error);
              displayMessage('AI', 'Sorry, I encountered a server error. Please try again.', 'bot-message');
          });
      }
  }

  function handleResponse(response) {
      if (response && Array.isArray(response.response)) {
          response.response.sort((a, b) => a.created_at - b.created_at);
          playNotificationSound();
          response.response.forEach(message => {
              if (message.content && message.role === 'assistant') {
                  const content = Array.isArray(message.content) ? message.content.join(' ') : message.content;
                  displayMessage('AI', content, 'bot-message');
              }
          });
      } else {
          const content = typeof response === 'object' ? JSON.stringify(response) : response;
          displayMessage('AI', content, 'bot-message');
      }
  }

  function displayMessage(sender, message, className) {
      const chatMessages = document.querySelector('.chat-messages');
      const msgElement = document.createElement('div');
      msgElement.className = `chat-message ${className}`;
      msgElement.innerHTML = `<strong>${sender}:</strong> ${formatMessage(message)}`;
      chatMessages.appendChild(msgElement);
      chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function formatMessage(message) {
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      return message.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
  }

  function showTypingIndicator() {
      const chatMessages = document.querySelector('.chat-messages');
      const typingIndicator = document.createElement('div');
      typingIndicator.className = 'typing-indicator';
      typingIndicator.innerHTML = 'typing<span></span><span></span><span></span>';
      chatMessages.appendChild(typingIndicator);
      chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function hideTypingIndicator() {
      const typingIndicator = document.querySelector('.typing-indicator');
      if (typingIndicator) {
          typingIndicator.remove();
      }
  }

  function playNotificationSound() {
      const audio = new Audio('/http://127.0.0.1:5000/static/sound/livechat.mp3');
      audio.play();
  }

  function watchColorChanges() {
      const colorDefinitions = document.getElementById('chatbot-colors');
      if (colorDefinitions) {
          const observer = new MutationObserver(() => {
              updateStyles();
          });
          observer.observe(colorDefinitions, { childList: true, characterData: true, subtree: true });
      }
  }

  // Initialize
  loadFontAwesome();
  updateStyles();
  createChatbot();
  watchColorChanges();
})();

